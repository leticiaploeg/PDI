clc
clear
close all

I = zeros(500, 500, 3, 'uint8');
for i = 1 : 500
    I(:,1,:) = i;
end

imshow(I)